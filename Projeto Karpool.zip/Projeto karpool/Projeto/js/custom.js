(function ($) {

	$('.vegas-slider').vegas({
		slider: [
		{src: 'images/slides/1.jpg'}
		{src: 'images/slides/2.jpg'}
		{src: 'images/slides/3.jpg'}
		
		]
	})
	


}) (jQuery);