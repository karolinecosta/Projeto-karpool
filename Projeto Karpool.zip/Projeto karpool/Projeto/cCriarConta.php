<?php 

	$nome = $_POST['nome'];
	$cpf = $_POST ['cpf'];
	$email = $_POST['email'];
	$telefone = $_POST['telefone'];
	$endereco = $_POST['endereco'];
	$veiculo = $_POST['veiculo'];
	$login = $_POST['login'];
	$senha = $_POST['senha'];

	$conexao = mysql_connect("localhost", "root", "");
	$schema = mysql_select_db("karpool", $conexao);
	
	if($nome == "" OR $cpf == "" $email == "" OR $telefone == "" OR $endereco == "" OR $veiculo == "" OR $login == "" OR $senha == ""){
		echo $msg = "<br/>Os campos obrigatórios não foram preenchidos. Verifique!";
	} 
	
	$sql = "INSERT INTO cadastro (nome, cpf, email, telefone, endereco, veiculo, login, senha) 
	VALUES ('$nome', '$cpf', '$email' '$telefone', '$endereco', '$veiculo', '$login', '$senha')";
	$resultado = mysql_query($sql,$conexao);
		
	
	if($resultado == TRUE){
			header("Location: login.html?m=$msg");
			exit; //parar a execução do código
		}else{
			$msg = "<p>Não foi possível cadastrar o usuário. Verifique!</p>";
			$msg .= mysql_error($conexao);
			echo $msg;
		}	