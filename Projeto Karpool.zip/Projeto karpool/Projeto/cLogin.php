<?php

	$login=$_POST['login'];
	$senha=$_POST['senha'];
	
	//verificar se campos obrigatorios foram preenchidos
	if($login == "" OR $senha == ""){
		$msg = "Campos obrigatórios nao preenchidos!";
		header("Location: index.html?m=$msg");
		exit;
	}

	//conectar no bd
	$conexao = mysql_connect("localhost", "root", "");
	$schema = mysql_select_db("karpool", $conexao);
	
	$sql = "SELECT login, senha FROM usuario WHERE login = '$login'";
	$resultado = mysql_query($sql,$conexao);	
	$arResult = mysql_fetch_assoc($resultado);
	
	$logincadastrado = $arResult['login'];
	$senhaCadastrado = $arResult['senha'];
	
	if($login == $logincadastrado){
	//verificando se a senha digitado é igual a senha salva no bd		
		if($senha == $senhaCadastrado){
			$msg="SEJA BEM VINDO";
			header("Location:rotas.html?m=$msg");
			exit;
		}else{
			$msg="Senha não confere!";
			header("Location: login.html?m=$msg");
			exit;
			}
			
	}/*else{
		$msg = "Usuário não cadastrado!";
		header("Location: index.html?m=$msg");
		exit;
	}*/
	
	









?>