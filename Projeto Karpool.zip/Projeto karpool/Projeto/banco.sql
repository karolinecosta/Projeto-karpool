CREATE DATABASE karpool;

USE karpool;

CREATE TABLE usuario (
	login VARCHAR (20) NOT NULL PRIMARY KEY,
    senha VARCHAR (20) NOT NULL
);
	
CREATE TABLE cadastro (
	nome VARCHAR (45) NOT NULL,
	cpf BIGINT (14) NOT NULL PRIMARY KEY,
	email VARCHAR (45) NOT NULL,
    telefone BIGINT (15) NOT NULL,
	endereco VARCHAR (40) NOT NULL,
	veiculo VARCHAR (40) NOT NULL,
	senha VARCHAR (20) NOT NULL
);
	
CREATE TABLE comentarios (
	email VARCHAR (45) NOT NULL,
    comentario VARCHAR (300) NOT NULL
);

CREATE TABLE rotas (
	origem VARCHAR (25) NOT NULL,
    destino VARCHAR (25) NOT NULL
);


-- INSERT INTO usuario (LOGIN, SENHA) VALUES ('adm.Eduardo', 'sinucaDF');


select * from usuario;
select * from cadastro;
select * from comentarios;
select * from rotas;
